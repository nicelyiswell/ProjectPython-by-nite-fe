text = input()
for i in text:
    print(text[0]+text[:-1])
